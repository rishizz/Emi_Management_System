import { TestBed } from '@angular/core/testing';

import { EmiPlanService } from './service/emi-plan.service';

describe('EmiPlanService', () => {
  let service: EmiPlanService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmiPlanService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
