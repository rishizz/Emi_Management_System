import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject} from 'rxjs';
import { User } from '../model/user';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthServiceService {

  public loginUrl = 'http://localhost:8084/api/users/login';
  public registerUrl = 'http://localhost:8084/api/users/register';
  isLoggedInSubject = new BehaviorSubject<boolean>(false);
  authenticated:boolean=false;


  constructor(private http: HttpClient,private router:Router) {}
  login(user:any) {
    return this.http.post<User>(this.loginUrl,user);
  }
  checkAuthentication(user:any,userBackend:any){
    if(user.username==userBackend.username && user.password==userBackend.password){
      this.authenticated=true;
      sessionStorage.setItem('username',user.username);
      sessionStorage.setItem('role',userBackend.role);
    }else{
      this.authenticated = false;
    }
    return this.authenticated;

  }
  isUserLoggedIn(){
    let user = sessionStorage.getItem('username');
    let role = sessionStorage.getItem('role');
    return (user !=null && role !=null);

  }
  isUserBankManager(){
    let role = sessionStorage.getItem('role');
    return role === 'Bank_Manager';

  }
  isUserCustomer(){
    let role = sessionStorage.getItem('role');
    return role === 'Customer';
  }
  register(user: User) {
    return this.http.post(this.registerUrl, user);
  }

  logout() {
    // remove user from session storage to log user out
    sessionStorage.removeItem('username');
    sessionStorage.removeItem('role');
    this.router.navigate(['/login']);

  }

}
