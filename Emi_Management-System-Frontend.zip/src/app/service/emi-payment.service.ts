import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { EmiPayment } from '../model/emi-payment';
import { PaymentMethod } from '../model/payment-method';


@Injectable({
  providedIn: 'root'
})
export class EmiPaymentService {
  private URL = 'http://localhost:8084/api';
  paymentMethod!:PaymentMethod[];
  emiPayment!:EmiPayment;
  
  constructor(private http:HttpClient ) {}
  getPaymentMethods(){
    return this.http.get<PaymentMethod[]>(this.URL+"/paymentmethods");
  }
  payEmiMethods(emiPayment:EmiPayment,customerId: number, loanPlanId: number, paymentMethodId: number){
    const headers = { 'content-type': 'application/json'}  
    const body = JSON.stringify(emiPayment);
    return this.http.post(this.URL + '/emiplans' + '/' + customerId + '/' + loanPlanId + '?paymentMethodId=' + paymentMethodId, body, {'headers':headers});
  }
  searchPaymentHistory(customerId:Number,loanPlanId:Number){
    return this.http.get<EmiPayment[]>(this.URL+'/emiplans'+'/'+customerId+'/'+loanPlanId+'/paymenthistory');
  }
}
