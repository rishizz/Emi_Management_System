import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Emiplan } from '../model/emiplan';

@Injectable({
  providedIn: 'root'
})
export class EmiPlanService {
  private EmiPlanURL = 'http://localhost:8084/api/emiplans';
  emiPlan!:Emiplan[];
  constructor(private http:HttpClient) { }
  addNewEmi(emiPlan:Emiplan){
    // console.log("Data",this.http.post<any>(this.EmiPlanURL,emiPlan));
    return this.http.post<any>(this.EmiPlanURL,emiPlan);

  }
  searchEmiPlan(customerId:number,loanPlanId:number){
    // console.log("Data",this.http.get<Emiplan>(this.EmiPlanURL+'/'+customerId+'/'+loanPlanId));
    return this.http.get<Emiplan>(this.EmiPlanURL+'/'+customerId+'/'+loanPlanId);
  }
}
