import { CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthServiceService as AuthService} from '../service/auth-service.service';
import { ToastrService } from 'ngx-toastr';
export const managerGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const toast = inject(ToastrService);
  if(authService.isUserLoggedIn() && authService.isUserBankManager()){
    return true;
  }
  else if(authService.isUserLoggedIn() && !authService.isUserBankManager()){
    toast.warning('You are not authorized to access this service!');
    // alert("Not authorized");
    return false;
  }
  else{
    router.navigate(['/login']);
    return false;
  }
};
