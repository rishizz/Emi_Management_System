import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthServiceService as AuthService } from '../service/auth-service.service';
import { ToastrService } from 'ngx-toastr';

export const userGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService  );
  const router = inject(Router);
  const toast = inject(ToastrService);


  if(authService.isUserLoggedIn() && authService.isUserCustomer()){
    return true;
  }
  else if(authService.isUserLoggedIn() && !authService.isUserCustomer()){
    toast.warning('You are not authorized to access this service!');
    return false;
  }
  else{
    router.navigate(['/login']);
    return false;
  }
};
