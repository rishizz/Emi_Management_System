import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { managerUserGuard } from './manager-user.guard';

describe('managerUserGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => managerUserGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
