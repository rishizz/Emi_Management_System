import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { EmiPaymentService } from '../service/emi-payment.service';
import { EmiPayment } from '../model/emi-payment';
import { DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-pay-emi',
  templateUrl: './pay-emi.component.html',
  styleUrl: './pay-emi.component.css'
})
export class PayEMIComponent implements OnInit{
  paymentMethods:any[] =[];
  emiPayment:EmiPayment = new EmiPayment();
  payEmiForm = new FormGroup({
    emiPaymentId:new FormControl(null,Validators.compose(
      [
        Validators.required,
        Validators.min(1)
      ]
    )),
    customerId: new FormControl(null, Validators.compose(
      [
        Validators.required,
        Validators.min(1)
      ]
    )),
    loanPlanId: new FormControl(null, Validators.compose(
      [
        Validators.required,
        Validators.min(1)

      ]
    )),
    // emiAmount: new FormControl(null, Validators.compose(
    //   [
    //     Validators.required,
    //     Validators.min(1)
    //   ]
    // )),
    date: new FormControl(this.datePipe.transform(new Date(), 'yyyy-MM-dd')),
    paymentMethodId: new FormControl(0,Validators.compose(
      [
        Validators.required,
      ]
    ))
})
constructor(private formBuilder: FormBuilder,private emiPaymentService:EmiPaymentService,private datePipe:DatePipe,private toast:ToastrService){
}
ngOnInit(): void {
  this.emiPaymentService.getPaymentMethods().subscribe({
    next:((data: any[])=>{
      this.paymentMethods = data;
      if (this.paymentMethods.length > 0) {
        this.payEmiForm.controls.paymentMethodId.setValue(this.paymentMethods[0].id);
      }
    }),
    error:((error:any)=>{
      console.log("Error",error);
      this.toast.error("Error While Fetching Payment Method!");
    })
  })
}
formatDate(date: Date): string {
  const d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();

  return [year, month.padStart(2, '0'), day.padStart(2, '0')].join('-');
}
payEmi(){
  if(this.payEmiForm.valid){
    this.emiPayment.id = this.payEmiForm.value.emiPaymentId!;
    // this.emiPayment.amount = this.payEmiForm.value.emiAmount!;
    this.emiPayment.paymentDate = this.payEmiForm.value.date!;
    const customerId = this.payEmiForm.value.customerId!;
    const loanPlanId = this.payEmiForm.value.loanPlanId!;
    const paymentMethod = this.payEmiForm.value.paymentMethodId!;

    this.emiPaymentService.payEmiMethods(this.emiPayment,customerId,loanPlanId,paymentMethod).subscribe({
      next:(success:any) => {
        this.toast.success(`Total Amount paid: ${success.amount + success.lateFee}`,"Emi Paid SuccessFully!");
        this.payEmiForm.reset({
        date:this.payEmiForm.get('date')?.value,
        paymentMethodId:this.payEmiForm.get('paymentMethodId')?.value
        });
        console.log("Response Status",success);
      },
      error:(error:any)=> {
          this.toast.error(error,"Error");
      }
    });
  }
}

}
