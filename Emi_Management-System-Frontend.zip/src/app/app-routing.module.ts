import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NewEMIPlanFormComponent } from './new-emiplan-form/new-emiplan-form.component';
import { MyEMIPlanComponent } from './my-emiplan/my-emiplan.component';
import { PayEMIComponent } from './pay-emi/pay-emi.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { managerUserGuard } from './guard/manager-user.guard';
import { managerGuard } from './guard/manager.guard';
import { userGuard } from './guard/user.guard';


const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  {path:'login',component:LoginComponent},
  {path:'register',component:RegisterComponent},
  { path: 'home', component: HomeComponent,canActivate:[managerUserGuard] },
  { path: 'new-emi-plan', component: NewEMIPlanFormComponent ,canActivate:[managerGuard]},
  { path: 'view-emi-plan', component: MyEMIPlanComponent,canActivate:[managerUserGuard] },
  { path: 'pay-emi', component: PayEMIComponent,canActivate:[userGuard] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
