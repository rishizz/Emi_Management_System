import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { AuthServiceService as AuthService } from '../service/auth-service.service';
@Component({
  selector: 'app-side-navbar',
  templateUrl: './side-navbar.component.html',
  styleUrl: './side-navbar.component.css'
})
export class SideNavbarComponent {
  @ViewChild(MatSidenav)
  sidenav!:MatSidenav;
  isMobile=true;
  isCollapsed = true;
  // isLoggedInSubject:Observable<boolean>;

  // constructor(private observer: BreakpointObserver,private authService: AuthServiceService){
  //   this.isLoggedInSubject = this.authService.isLoggedInSubject.asObservable();
  // }
  constructor(private observer:BreakpointObserver,private authService:AuthService){}
  
  // isLoggedIn(): boolean {
  //   return this.authService.isLoggedIn();
  // }
  ngOnInit(){
    this.observer.observe(['max-width: 800px']).subscribe((screenSize)=> {
      if(screenSize.matches){
        this.isMobile = true;
      }else{
        this.isMobile = false;
      }
    });
  }
  toggleMenu(){
    if(this.isMobile){
      this.sidenav.toggle();
      this.isCollapsed=false;
    }else{
      this.sidenav.open();
      this.isCollapsed = !this.isCollapsed;
    }
  }
  logout(){
    this.authService.logout();
  }

}
