import { EmiPayment } from './emi-payment';

describe('EmiPayment', () => {
  it('should create an instance', () => {
    expect(new EmiPayment()).toBeTruthy();
  });
});
