export class Emiplan {
    id!: number;
    customerId!: number;
    loanPlanId!: number;
    emiAmount!: number;
    emiStart!: string;
    numberOfEmi!: number;
    customerName!: string;
    customerPhone!: string;
    customerAddress!: string;
    customerPan!: string;
    emiStatus!: string;

}
