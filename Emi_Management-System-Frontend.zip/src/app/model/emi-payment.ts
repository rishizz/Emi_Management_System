export class EmiPayment {
    id!: number;
    amount!: number;
    paymentDate!: string;
    lateFee!: number;
    paymentMethodId!: number;
    emiId!: number;
}