import { Emiplan } from './emiplan';

describe('Emiplan', () => {
  it('should create an instance', () => {
    expect(new Emiplan()).toBeTruthy();
  });
});
