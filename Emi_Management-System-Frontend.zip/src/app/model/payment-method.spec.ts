import { PaymentMethod } from './payment-method';

describe('PaymentMethod', () => {
  it('should create an instance', () => {
    expect(new PaymentMethod()).toBeTruthy();
  });
});
