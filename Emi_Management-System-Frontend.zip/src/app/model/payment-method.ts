export class PaymentMethod {
}
