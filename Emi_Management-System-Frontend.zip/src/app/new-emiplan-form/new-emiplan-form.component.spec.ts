import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewEMIPlanFormComponent } from './new-emiplan-form.component';

describe('NewEMIPlanFormComponent', () => {
  let component: NewEMIPlanFormComponent;
  let fixture: ComponentFixture<NewEMIPlanFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NewEMIPlanFormComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(NewEMIPlanFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
