import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Emiplan } from '../model/emiplan';
import { EmiPlanService } from '../service/emi-plan.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-new-emiplan-form',
  templateUrl: './new-emiplan-form.component.html',
  styleUrl: './new-emiplan-form.component.css'
})
export class NewEMIPlanFormComponent {
  emiPlan : Emiplan = new Emiplan();
  today = new Date().toISOString().split('T')[0];
  addEmiForm = new FormGroup({
    emiId:new FormControl(0,Validators.compose(
      [
        Validators.required,
        Validators.min(1)
      ]
    )),
    customerId: new FormControl(0, Validators.compose(
      [
        Validators.required,
        Validators.min(1)
      ]
    )),
    loanPlanId: new FormControl(0, Validators.compose(
      [
        Validators.required,
        Validators.min(1)

      ]
    )),
    emiAmount: new FormControl(0, Validators.compose(
      [
        Validators.required,
        Validators.min(1)
      ]
    )),
    emiStart: new FormControl('', Validators.required),
    numberOfEmi: new FormControl(0, Validators.compose([
      Validators.required,
      Validators.min(1)
    ])),
    customerName: new FormControl('', Validators.compose(
      [
        Validators.required,
        Validators.pattern('[a-zA-Z ]{0,30}')
      ]
    )),
    customerPhone: new FormControl('', Validators.compose(
      [
        Validators.required,
        Validators.pattern('[0-9]{10,10}')
      ]
    )),
    customerAddress: new FormControl('', Validators.compose(
      [
        Validators.required,
        Validators.pattern('[a-zA-Z]{0,30}')
      ]
    )),
    customerPan: new FormControl('', Validators.compose(
      [
        Validators.required,
        Validators.pattern('[a-zA-Z0-9]{12,12}')
      ]
    )),
    emiStatus: new FormControl('onGoing', Validators.required)
  })
  constructor(private emiPlanService:EmiPlanService,private toast:ToastrService){}
  addEmiPlan(){
    this.emiPlan.id=this.addEmiForm.value.emiId!;
    this.emiPlan.customerId = this.addEmiForm.value.customerId!;
    this.emiPlan.loanPlanId = this.addEmiForm.value.loanPlanId!;
    this.emiPlan.emiAmount = this.addEmiForm.value.emiAmount!;
    this.emiPlan.emiStart = this.addEmiForm.value.emiStart!;
    this.emiPlan.numberOfEmi = this.addEmiForm.value.numberOfEmi!;
    this.emiPlan.customerName = this.addEmiForm.value.customerName!;
    this.emiPlan.customerPhone = this.addEmiForm.value.customerPhone!;
    this.emiPlan.customerAddress = this.addEmiForm.value.customerAddress!;
    this.emiPlan.customerPan = this.addEmiForm.value.customerPan!;
    this.emiPlan.emiStatus = this.addEmiForm.value.emiStatus!;

    this.emiPlanService.addNewEmi(this.emiPlan).subscribe({
      next:(success:any) => {
        this.addEmiForm.reset();
        this.toast.success("New Emi Plan Added Successfully!","Success");
        // console.log("Response Status",success);
      },
      error:(error:any)=> {
        if(error.status===201){
          this.addEmiForm.reset();
          this.toast.success("New Emi Plan Added Successfully!");
        }else if(error.status===400){
        this.toast.error(error.error,"Error")
        }
        else{
          this.toast.error("Error while creating new emi plan","Error");
        }
      }
    });
    this.emiPlan = new Emiplan();
  }
}
