import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Emiplan } from '../model/emiplan';
import { EmiPlanService } from '../service/emi-plan.service';
import { EmiPaymentService } from '../service/emi-payment.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-my-emiplan',
  templateUrl: './my-emiplan.component.html',
  styleUrl: './my-emiplan.component.css'
})
export class MyEMIPlanComponent implements OnInit{
  emiPlan:Emiplan = new Emiplan();
  emiPlanData:any;
  paymentHistoryData:any;
  searchForm: FormGroup = this.formBuilder.group({
    customerId: ['', Validators.required],
    loanPlanId: ['', Validators.required],
  });;
  constructor(private formBuilder: FormBuilder,private emiPlanService:EmiPlanService,private emiPaymentService:EmiPaymentService,private toast:ToastrService) {}
  ngOnInit() {

  }
  fetchEMIPlan() {
    this.emiPlan.customerId = this.searchForm.value.customerId;
    this.emiPlan.loanPlanId = this.searchForm.value.loanPlanId;
    this.emiPlanService.searchEmiPlan(this.emiPlan.customerId,this.emiPlan.loanPlanId).subscribe({
     next:(success:any)=>{
        this.toast.success("Data Fetched Successfully!", "Emi Plan");
        this.emiPlanData=success;
      },
    error:(error:any)=>{
      if(error.status==404){
      this.toast.error("Data not available for above ID's","Error !");
      this.emiPlanData='';
      }
      else{
        this.toast.error("Internal Server Error","Error!");
        this.paymentHistoryData = '';
        // console.error(error,"Error");
      }
    }
  })
  }
  fetchPaymentHistory(){
    const customerId = this.searchForm.value.customerId;
    const loanPlanId = this.searchForm.value.loanPlanId;
    this.emiPaymentService.searchPaymentHistory(customerId,loanPlanId).subscribe({
      next:(data:any)=>{
        this.paymentHistoryData = data;
        this.toast.success("Data Fetched Successfully!","Payment History");
      },
      error:(error:any)=>{
        if(error.status==404){
          this.toast.error("Data not available for above ID's","Error !");
          this.paymentHistoryData = '';
          }
          else{
            this.toast.error(error.error,"Error!");
            this.paymentHistoryData = '';
            // console.error(error,"Error");
          }
      }
    })
  }
}
