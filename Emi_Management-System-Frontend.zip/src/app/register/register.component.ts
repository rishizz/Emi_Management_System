import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService as AuthService } from '../service/auth-service.service';
import { User } from '../model/user';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user:User=new User();
  registerForm= new FormGroup({
    username: new FormControl("", [Validators.required]),
    role:new FormControl("",[Validators.required]),
      password: new FormControl("", [
        Validators.required,
        Validators.pattern(
          /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/gm,
        ),
      ]),
      confirmPassword: new FormControl("", [
        Validators.required,
        Validators.pattern(
          /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/gm,
        ),
      ]),
  })

  constructor(private authService:AuthService,private router:Router,private toast:ToastrService) { }

  ngOnInit(): void {}

  register() {
    this.user.username = this.registerForm.value.username!;
    this.user.password = this.registerForm.value.password!;
    this.user.role =  this.registerForm.value.role!;
    this.authService.register(this.user).subscribe({
      next:(response)=>{
        this.toast.success("Registeration Successful!",`Hi ,${this.user.username}!`);
          this.router.navigate(['/home']);
      },
      error:(error)=>{
        if(error.status==500){
        this.toast.error(`Error`,"Error while Registering");
        }
      }
    })



    
  }

}
