import { Component} from '@angular/core';
import { AuthServiceService } from './service/auth-service.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'emi-management-system';
  isLoggedIn = false;

  constructor(public authService:AuthServiceService){}
  ngOnInit(){
    this.isLoggedIn = this.authService.isUserLoggedIn();
  }
}
