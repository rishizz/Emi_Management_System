import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormControl,FormGroup,Validators } from '@angular/forms';
import {Router} from '@angular/router';
import {AuthServiceService as AuthService} from '../service/auth-service.service';
import { User } from '../model/user';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit{
  user:User=new User();
  userBackend:User = new User();
  loginForm = new FormGroup({
    username:new FormControl('',Validators.required),
    password:new FormControl('',Validators.required)

  });

  constructor(private fb: FormBuilder, private router: Router,private authService:AuthService,private toast:ToastrService) {}

  ngOnInit(): void {}

  onSubmit() {
    this.user.username = this.loginForm.value.username!;
    this.user.password = this.loginForm.value.password!;
    this.authService.login(this.user).subscribe({
      next:(response)=>{
        this.loginForm.reset();
        this.toast.success("Welcome to Emi-Mangement System",this.user.username);
        this.userBackend.username=response.username;
        this.userBackend.password=response.password;
        this.userBackend.role=response.role;
        if(this.authService.checkAuthentication(this.user,this.userBackend)){
          this.router.navigate(['/home']);
        }else{
          this.toast.error('Either username or password is incorrect!',"Hi there!");
        }
      },
        error:(error)=>{
          this.toast.error("Either Username or Password incorrect!","Hi there!");
        }
    });
  } 
}




