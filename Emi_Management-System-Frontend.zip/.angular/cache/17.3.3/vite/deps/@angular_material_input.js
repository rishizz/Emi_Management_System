import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-3BFU6EOH.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-5JWSNHKJ.js";
import "./chunk-YMIOXJAU.js";
import "./chunk-MFQ3XLYA.js";
import "./chunk-W3BLW2EL.js";
import "./chunk-JJXLXFG2.js";
import "./chunk-HFOQLTAW.js";
import "./chunk-4FFVUQGS.js";
import "./chunk-SXIXOCJ4.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
