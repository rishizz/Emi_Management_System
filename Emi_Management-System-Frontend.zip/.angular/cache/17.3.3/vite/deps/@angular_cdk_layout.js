import {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
} from "./chunk-JJXLXFG2.js";
import "./chunk-HFOQLTAW.js";
import "./chunk-4FFVUQGS.js";
import "./chunk-SXIXOCJ4.js";
export {
  BreakpointObserver,
  Breakpoints,
  LayoutModule,
  MediaMatcher
};
//# sourceMappingURL=@angular_cdk_layout.js.map
